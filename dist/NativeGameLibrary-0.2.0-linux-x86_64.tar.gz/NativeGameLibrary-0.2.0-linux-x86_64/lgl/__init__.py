"""Native Game Library — browse and download from the Internet Archive."""

__version__ = "0.2.0"
APP_ID = "io.github.nativegamelibrary.NativeGameLibrary"
APP_NAME = "Native Game Library"
