import 'package:material_ui/material_ui.dart';

/// Spacing scale from `lgl/theme.py` (`SPACE`): 4, 8, 16, 24, 32, 48.
abstract final class LumoraSpacing {
  static const double xs = 4;
  static const double sm = 8;
  static const double md = 16;
  static const double lg = 24;
  static const double xl = 32;
  static const double xxl = 48;
}

/// Radii from `lgl/theme.py` (`RADIUS`): cards/buttons, dialogs, pills.
abstract final class LumoraRadius {
  static const double sm = 6;
  static const double md = 8;
  static const double lg = 12;
  static const double pill = 999;
}

/// Extra semantic colours that [ColorScheme] does not carry. Read with
/// [LumoraTheme.colorsOf].
@immutable
class LumoraColors extends ThemeExtension<LumoraColors> {
  const LumoraColors({
    required this.background,
    required this.surface,
    required this.raised,
    required this.hover,
    required this.divider,
    required this.text,
    required this.muted,
    required this.faint,
    required this.accent,
    required this.accentFill,
    required this.accentText,
    required this.onAccent,
    required this.success,
    required this.warning,
    required this.danger,
    required this.favorite,
  });

  final Color background;
  final Color surface;
  final Color raised;
  final Color hover;
  final Color divider;
  final Color text;
  final Color muted;
  final Color faint;
  final Color accent;
  final Color accentFill;
  final Color accentText;
  final Color onAccent;
  final Color success;
  final Color warning;
  final Color danger;
  final Color favorite;

  /// PC token name used by rows that sit on a raised card.
  Color get border => divider;

  /// Alias kept for widgets that call the raised surface `surfaceHigh`.
  Color get surfaceHigh => raised;

  @override
  LumoraColors copyWith({
    Color? background,
    Color? surface,
    Color? raised,
    Color? hover,
    Color? divider,
    Color? text,
    Color? muted,
    Color? faint,
    Color? accent,
    Color? accentFill,
    Color? accentText,
    Color? onAccent,
    Color? success,
    Color? warning,
    Color? danger,
    Color? favorite,
  }) {
    return LumoraColors(
      background: background ?? this.background,
      surface: surface ?? this.surface,
      raised: raised ?? this.raised,
      hover: hover ?? this.hover,
      divider: divider ?? this.divider,
      text: text ?? this.text,
      muted: muted ?? this.muted,
      faint: faint ?? this.faint,
      accent: accent ?? this.accent,
      accentFill: accentFill ?? this.accentFill,
      accentText: accentText ?? this.accentText,
      onAccent: onAccent ?? this.onAccent,
      success: success ?? this.success,
      warning: warning ?? this.warning,
      danger: danger ?? this.danger,
      favorite: favorite ?? this.favorite,
    );
  }

  @override
  LumoraColors lerp(ThemeExtension<LumoraColors>? other, double t) {
    if (other is! LumoraColors) {
      return this;
    }
    return LumoraColors(
      background: Color.lerp(background, other.background, t)!,
      surface: Color.lerp(surface, other.surface, t)!,
      raised: Color.lerp(raised, other.raised, t)!,
      hover: Color.lerp(hover, other.hover, t)!,
      divider: Color.lerp(divider, other.divider, t)!,
      text: Color.lerp(text, other.text, t)!,
      muted: Color.lerp(muted, other.muted, t)!,
      faint: Color.lerp(faint, other.faint, t)!,
      accent: Color.lerp(accent, other.accent, t)!,
      accentFill: Color.lerp(accentFill, other.accentFill, t)!,
      accentText: Color.lerp(accentText, other.accentText, t)!,
      onAccent: Color.lerp(onAccent, other.onAccent, t)!,
      success: Color.lerp(success, other.success, t)!,
      warning: Color.lerp(warning, other.warning, t)!,
      danger: Color.lerp(danger, other.danger, t)!,
      favorite: Color.lerp(favorite, other.favorite, t)!,
    );
  }
}

/// The single source of truth for Lumora's phone look.
///
/// Ported from the PC `lgl/theme.py`: same palette tokens, spacing scale,
/// radii and type sizes. The PC calls the link colour `accent_text` and the
/// filled-surface colour `accent_fill`; both are kept separate here for the
/// same contrast reason (white on #3b82f6 is only 3.7:1).
abstract final class LumoraTheme {
  /// Chart/selection blue (`theme.ACCENT`).
  static const Color accent = Color(0xFF3B82F6);

  /// Filled surfaces that carry white labels (`theme.ACCENT_FILL`).
  static const Color accentFill = Color(0xFF2563EB);
  static const Color accentFillHover = Color(0xFF1D4ED8);
  static const Color favorite = Color(0xFFB8863B);

  // Dark (`theme.DARK`).
  static const Color darkBackground = Color(0xFF101216);
  static const Color darkSurface = Color(0xFF171A20);
  static const Color darkRaised = Color(0xFF1E222A);
  static const Color darkHover = Color(0xFF262B34);
  static const Color darkDivider = Color(0xFF262B34);
  static const Color darkText = Color(0xFFE8EAED);
  static const Color darkMuted = Color(0xFF9AA3AF);
  static const Color darkFaint = Color(0xFF6B7280);
  static const Color darkAccentText = Color(0xFF7DB2FF);
  static const Color darkSuccess = Color(0xFF22C55E);
  static const Color darkWarning = Color(0xFFF59E0B);
  static const Color darkDanger = Color(0xFFEF4444);

  // Light (`theme.LIGHT`).
  static const Color lightBackground = Color(0xFFF5F6F8);
  static const Color lightSurface = Color(0xFFFFFFFF);
  static const Color lightRaised = Color(0xFFFFFFFF);
  static const Color lightHover = Color(0xFFECEEF2);
  static const Color lightDivider = Color(0xFFE5E7EB);
  static const Color lightText = Color(0xFF111827);
  static const Color lightMuted = Color(0xFF5F6673);
  static const Color lightFaint = Color(0xFF9CA3AF);
  static const Color lightAccentText = Color(0xFF1D4ED8);
  static const Color lightSuccess = Color(0xFF15803D);
  static const Color lightWarning = Color(0xFFB45309);
  static const Color lightDanger = Color(0xFFC02626);

  static const double spaceXs = LumoraSpacing.xs;
  static const double spaceSm = LumoraSpacing.sm;
  static const double spaceMd = LumoraSpacing.md;
  static const double spaceLg = LumoraSpacing.lg;
  static const double spaceXl = LumoraSpacing.xl;
  static const double spaceXxl = LumoraSpacing.xxl;

  static const double radiusSm = LumoraRadius.sm;
  static const double radiusMd = LumoraRadius.md;
  static const double radiusLg = LumoraRadius.lg;
  static const double radiusPill = LumoraRadius.pill;

  /// WCAG 2.1 contrast ratio between two opaque colours (1.0 – 21.0).
  static double contrastRatio(Color a, Color b) {
    final first = a.computeLuminance();
    final second = b.computeLuminance();
    final lighter = first > second ? first : second;
    final darker = first > second ? second : first;
    return (lighter + 0.05) / (darker + 0.05);
  }

  /// A contrast-safe label colour for [accent] as a filled surface.
  ///
  /// Mirrors the PC `with_accent()` idea: keep white where it reaches AA,
  /// otherwise switch to ink.
  static Color onAccent(Color accent) {
    return contrastRatio(accent, Colors.white) >= 4.5
        ? Colors.white
        : const Color(0xFF0B0E14);
  }

  /// The fill shade for buttons and selected controls.
  ///
  /// The default accent keeps the PC's exact `accent_fill`. A custom accent is
  /// darkened in small steps until white labels clear 4.5:1.
  static Color filled(Color accent) {
    if (accent.toARGB32() == LumoraTheme.accent.toARGB32()) {
      return accentFill;
    }
    var color = accent;
    for (var step = 0; step < 12; step++) {
      if (contrastRatio(color, Colors.white) >= 4.5) {
        return color;
      }
      color = Color.lerp(color, Colors.black, 0.08)!;
    }
    return color;
  }

  /// A low-emphasis accent wash for selected rows, chips and badges.
  static Color accentWash(
    Color accent,
    Color surface, {
    double opacity = 0.18,
  }) {
    return Color.alphaBlend(accent.withValues(alpha: opacity), surface);
  }

  /// Convenience accessor for [LumoraColors].
  static LumoraColors colorsOf(BuildContext context) {
    return Theme.of(context).extension<LumoraColors>() ?? darkColors(accent);
  }

  static LumoraColors darkColors(Color accentColor) {
    final fill = filled(accentColor);
    return LumoraColors(
      background: darkBackground,
      surface: darkSurface,
      raised: darkRaised,
      hover: darkHover,
      divider: darkDivider,
      text: darkText,
      muted: darkMuted,
      faint: darkFaint,
      accent: accentColor,
      accentFill: fill,
      accentText: darkAccentText,
      onAccent: onAccent(fill),
      success: darkSuccess,
      warning: darkWarning,
      danger: darkDanger,
      favorite: favorite,
    );
  }

  static LumoraColors lightColors(Color accentColor) {
    final fill = filled(accentColor);
    return LumoraColors(
      background: lightBackground,
      surface: lightSurface,
      raised: lightRaised,
      hover: lightHover,
      divider: lightDivider,
      text: lightText,
      muted: lightMuted,
      faint: lightFaint,
      accent: accentColor,
      accentFill: fill,
      accentText: lightAccentText,
      onAccent: onAccent(fill),
      success: lightSuccess,
      warning: lightWarning,
      danger: lightDanger,
      favorite: favorite,
    );
  }

  static ThemeData dark(Color accent) => _build(
    brightness: Brightness.dark,
    accent: accent,
    background: darkBackground,
    surface: darkSurface,
    raised: darkRaised,
    hover: darkHover,
    divider: darkDivider,
    text: darkText,
    muted: darkMuted,
    colors: darkColors(accent),
  );

  static ThemeData light(Color accent) => _build(
    brightness: Brightness.light,
    accent: accent,
    background: lightBackground,
    surface: lightSurface,
    raised: lightRaised,
    hover: lightHover,
    divider: lightDivider,
    text: lightText,
    muted: lightMuted,
    colors: lightColors(accent),
  );

  static ThemeData _build({
    required Brightness brightness,
    required Color accent,
    required Color background,
    required Color surface,
    required Color raised,
    required Color hover,
    required Color divider,
    required Color text,
    required Color muted,
    required LumoraColors colors,
  }) {
    final base = ThemeData(
      useMaterial3: true,
      brightness: brightness,
      colorScheme:
          ColorScheme.fromSeed(
            seedColor: accent,
            brightness: brightness,
          ).copyWith(
            primary: accent,
            onPrimary: colors.onAccent,
            secondary: accent,
            onSecondary: colors.onAccent,
            surface: surface,
            onSurface: text,
            surfaceContainerHighest: raised,
            outline: divider,
            outlineVariant: divider,
            error: colors.danger,
            onError: colors.onAccent,
          ),
      scaffoldBackgroundColor: background,
      canvasColor: background,
      dividerColor: divider,
      splashFactory: InkSparkle.splashFactory,
      visualDensity: VisualDensity.compact,
      extensions: <ThemeExtension<dynamic>>[colors],
    );

    // Type scale from theme.TYPE: page 22, title 16, body 13, small 11.
    final textTheme = base.textTheme
        .apply(bodyColor: text, displayColor: text)
        .copyWith(
          headlineSmall: TextStyle(
            fontSize: 22,
            fontWeight: FontWeight.w700,
            color: text,
          ),
          titleLarge: TextStyle(
            fontSize: 18,
            fontWeight: FontWeight.w700,
            color: text,
          ),
          titleMedium: TextStyle(
            fontSize: 16,
            fontWeight: FontWeight.w600,
            color: text,
          ),
          bodyMedium: TextStyle(fontSize: 13, height: 1.4, color: text),
          bodySmall: TextStyle(fontSize: 11, height: 1.3, color: muted),
          labelLarge: const TextStyle(
            fontSize: 13,
            fontWeight: FontWeight.w600,
          ),
          labelSmall: TextStyle(fontSize: 11, color: muted),
        );

    final rounded = RoundedRectangleBorder(
      borderRadius: BorderRadius.circular(radiusMd),
    );
    final fill = colors.accentFill;

    return base.copyWith(
      textTheme: textTheme,
      primaryColor: accent,
      appBarTheme: AppBarTheme(
        backgroundColor: background,
        foregroundColor: text,
        surfaceTintColor: Colors.transparent,
        elevation: 0,
        scrolledUnderElevation: 0,
        centerTitle: false,
        iconTheme: IconThemeData(color: text, size: 24),
        titleTextStyle: TextStyle(
          fontSize: 20,
          fontWeight: FontWeight.w700,
          color: text,
        ),
        toolbarTextStyle: textTheme.bodyMedium,
      ),
      cardTheme: CardThemeData(
        color: raised,
        surfaceTintColor: Colors.transparent,
        shadowColor: Colors.black.withValues(alpha: 0.55),
        elevation: 0,
        margin: EdgeInsets.zero,
        clipBehavior: Clip.antiAlias,
        shape: rounded,
      ),
      dialogTheme: DialogThemeData(
        backgroundColor: raised,
        surfaceTintColor: Colors.transparent,
        titleTextStyle: textTheme.titleLarge,
        contentTextStyle: textTheme.bodyMedium,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(radiusLg),
        ),
      ),
      bottomSheetTheme: BottomSheetThemeData(
        backgroundColor: raised,
        surfaceTintColor: Colors.transparent,
        modalBackgroundColor: raised,
        shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.vertical(top: Radius.circular(radiusLg)),
        ),
      ),
      tabBarTheme: TabBarThemeData(
        labelColor: text,
        unselectedLabelColor: muted,
        indicatorColor: accent,
        indicatorSize: TabBarIndicatorSize.tab,
        dividerColor: divider,
        labelStyle: const TextStyle(fontSize: 13, fontWeight: FontWeight.w600),
        unselectedLabelStyle: const TextStyle(
          fontSize: 13,
          fontWeight: FontWeight.w500,
        ),
      ),
      inputDecorationTheme: InputDecorationTheme(
        filled: true,
        fillColor: raised,
        isDense: true,
        hintStyle: TextStyle(color: muted, fontSize: 13),
        labelStyle: TextStyle(color: muted, fontSize: 13),
        prefixIconColor: muted,
        suffixIconColor: muted,
        contentPadding: const EdgeInsets.symmetric(
          horizontal: spaceMd,
          vertical: spaceSm,
        ),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(radiusMd),
          borderSide: BorderSide(color: divider),
        ),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(radiusMd),
          borderSide: BorderSide(color: divider),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(radiusMd),
          borderSide: BorderSide(color: accent, width: 1.5),
        ),
        errorBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(radiusMd),
          borderSide: BorderSide(color: colors.danger),
        ),
        focusedErrorBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(radiusMd),
          borderSide: BorderSide(color: colors.danger, width: 1.5),
        ),
      ),
      filledButtonTheme: FilledButtonThemeData(
        style: FilledButton.styleFrom(
          backgroundColor: fill,
          foregroundColor: onAccent(fill),
          minimumSize: const Size(0, 44),
          padding: const EdgeInsets.symmetric(horizontal: spaceMd),
          shape: rounded,
          textStyle: const TextStyle(fontSize: 13, fontWeight: FontWeight.w600),
        ),
      ),
      outlinedButtonTheme: OutlinedButtonThemeData(
        style: OutlinedButton.styleFrom(
          foregroundColor: text,
          minimumSize: const Size(0, 44),
          padding: const EdgeInsets.symmetric(horizontal: spaceMd),
          side: BorderSide(color: divider),
          shape: rounded,
          textStyle: const TextStyle(fontSize: 13, fontWeight: FontWeight.w600),
        ),
      ),
      textButtonTheme: TextButtonThemeData(
        style: TextButton.styleFrom(
          foregroundColor: colors.accentText,
          minimumSize: const Size(0, 44),
          shape: rounded,
          textStyle: const TextStyle(fontSize: 13, fontWeight: FontWeight.w600),
        ),
      ),
      iconButtonTheme: IconButtonThemeData(
        style: IconButton.styleFrom(
          foregroundColor: text,
          minimumSize: const Size(44, 44),
        ),
      ),
      switchTheme: SwitchThemeData(
        thumbColor: WidgetStateProperty.resolveWith((states) {
          if (states.contains(WidgetState.selected)) {
            return onAccent(fill);
          }
          return muted;
        }),
        trackColor: WidgetStateProperty.resolveWith((states) {
          if (states.contains(WidgetState.selected)) {
            return fill;
          }
          return hover;
        }),
        trackOutlineColor: WidgetStateProperty.resolveWith((states) {
          if (states.contains(WidgetState.selected)) {
            return Colors.transparent;
          }
          return divider;
        }),
      ),
      checkboxTheme: CheckboxThemeData(
        fillColor: WidgetStateProperty.resolveWith((states) {
          if (states.contains(WidgetState.selected)) {
            return fill;
          }
          return Colors.transparent;
        }),
        checkColor: WidgetStatePropertyAll(onAccent(fill)),
        side: BorderSide(color: divider, width: 1.5),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(radiusSm),
        ),
      ),
      sliderTheme: SliderThemeData(
        activeTrackColor: fill,
        inactiveTrackColor: hover,
        thumbColor: fill,
        overlayColor: accent.withValues(alpha: 0.14),
      ),
      progressIndicatorTheme: ProgressIndicatorThemeData(
        color: fill,
        linearTrackColor: hover,
        circularTrackColor: hover,
      ),
      dividerTheme: DividerThemeData(color: divider, thickness: 1, space: 1),
      chipTheme: ChipThemeData(
        backgroundColor: raised,
        selectedColor: accentWash(accent, raised),
        disabledColor: raised,
        side: BorderSide(color: divider),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(radiusPill),
        ),
        labelStyle: const TextStyle(fontSize: 11),
        padding: const EdgeInsets.symmetric(horizontal: spaceSm, vertical: 2),
      ),
      listTileTheme: ListTileThemeData(
        iconColor: muted,
        textColor: text,
        subtitleTextStyle: TextStyle(fontSize: 11, color: muted),
        contentPadding: const EdgeInsets.symmetric(horizontal: spaceMd),
        minVerticalPadding: spaceSm,
      ),
      snackBarTheme: SnackBarThemeData(
        backgroundColor: raised,
        contentTextStyle: TextStyle(color: text, fontSize: 13),
        actionTextColor: colors.accentText,
        behavior: SnackBarBehavior.floating,
        shape: rounded,
      ),
      tooltipTheme: TooltipThemeData(
        decoration: BoxDecoration(
          color: raised,
          borderRadius: BorderRadius.circular(radiusSm),
          border: Border.all(color: divider),
        ),
        textStyle: TextStyle(color: text, fontSize: 11),
      ),
      scrollbarTheme: ScrollbarThemeData(
        thumbColor: WidgetStatePropertyAll(divider),
        radius: const Radius.circular(radiusPill),
        thickness: const WidgetStatePropertyAll(4),
      ),
      popupMenuTheme: PopupMenuThemeData(
        color: raised,
        surfaceTintColor: Colors.transparent,
        shape: rounded,
        textStyle: textTheme.bodyMedium,
      ),
    );
  }
}
