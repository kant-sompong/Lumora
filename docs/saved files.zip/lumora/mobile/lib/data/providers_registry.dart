import '../models/media_item.dart';
import '../models/stream_provider.dart';

/// Every media streaming provider the PC app offers, in PC order
/// (`lgl/streaming.py`: `PROVIDERS` plus the anime-only `ani`).
///
/// URL templates are copied from `lgl/streaming.py` (`movie_url`,
/// `episode_url`, `ani_url`). `{tvSuffix}` expands to `/{season}/{episode}`
/// for TV and to nothing for movies; season/episode query parameters are
/// removed for movies. See `docs/mobile-providers.md`.
const List<StreamProvider> allProviders = <StreamProvider>[
  StreamProvider(
    id: 'cinesrc',
    name: 'CineSrc',
    urlTemplate: 'https://cinesrc.st/embed/{type}/{id}?s={season}&e={episode}',
    kinds: <MediaKind>{MediaKind.movie, MediaKind.tv},
  ),
  StreamProvider(
    id: 'rivestream',
    name: 'Rive',
    urlTemplate:
        'https://www.rivestream.app/embed?type={type}&id={id}&season={season}&episode={episode}',
    kinds: <MediaKind>{MediaKind.movie, MediaKind.tv},
  ),
  StreamProvider(
    id: 'toflix',
    name: 'ToFlix',
    urlTemplate: 'https://toflix.co/embed/{type}/{id}{tvSuffix}',
    kinds: <MediaKind>{MediaKind.movie, MediaKind.tv},
  ),
  StreamProvider(
    id: 'cinelite',
    name: 'CineLite',
    urlTemplate: 'https://embed.cinelite.xyz/{id}{tvSuffix}',
    kinds: <MediaKind>{MediaKind.movie, MediaKind.tv},
  ),
  StreamProvider(
    id: 'framextv',
    name: 'frameXTV',
    urlTemplate: 'https://framextv.xyz/embed/{id}{tvSuffix}',
    kinds: <MediaKind>{MediaKind.movie, MediaKind.tv},
  ),
  StreamProvider(
    id: 'atlantic',
    name: 'Atlantic',
    urlTemplate: 'https://atlantic.st/embed/{type}/{id}{tvSuffix}',
    kinds: <MediaKind>{MediaKind.movie, MediaKind.tv},
  ),
  StreamProvider(
    id: 'ani',
    name: 'ani.pm (anime)',
    urlTemplate: 'https://ani.pm/embed/ani/{id}/{episode}/sub',
    kinds: <MediaKind>{MediaKind.anime},
  ),
];

/// Looks up a provider by its persisted id, or null when it is unknown.
StreamProvider? providerById(String id) {
  for (final provider in allProviders) {
    if (provider.id == id) {
      return provider;
    }
  }
  return null;
}

/// All providers that can play [kind], in PC order.
List<StreamProvider> providersForKind(MediaKind kind) {
  return allProviders.where((provider) => provider.supports(kind)).toList();
}

/// Picks the provider used to play [kind].
///
/// [preferredId] wins when it is enabled and supports the kind. Otherwise the
/// first enabled provider that supports the kind is used, so an anime title
/// skips the TMDB providers and lands on ani.pm even when CineSrc is the
/// stored default.
StreamProvider? pickProvider({
  required MediaKind kind,
  List<String>? enabledProviderIds,
  String? preferredId,
}) {
  final ids =
      enabledProviderIds ??
      allProviders.map((provider) => provider.id).toList(growable: false);
  final available = <StreamProvider>[];
  for (final id in ids) {
    final provider = providerById(id);
    if (provider != null && provider.supports(kind)) {
      available.add(provider);
    }
  }
  if (available.isEmpty) {
    return null;
  }
  if (preferredId != null) {
    for (final provider in available) {
      if (provider.id == preferredId) {
        return provider;
      }
    }
  }
  return available.first;
}

/// Builds the full-screen player URL for [item] on [provider].
///
/// Movies use the TMDB id without season/episode; TV adds `{season}` and
/// `{episode}` (as `/s/e` path segments or `?s=&e=` query parameters); anime
/// uses its AniList id and episode, matching the PC `ani_url()`.
///
/// Throws [ArgumentError] when the provider cannot play the item's kind and
/// [MissingMediaIdException] when the item has no usable TMDB/AniList id.
Uri buildWatchUrl(
  StreamProvider provider,
  MediaItem item, {
  int season = 1,
  int episode = 1,
}) {
  if (!provider.supports(item.kind)) {
    throw ArgumentError('${provider.name} cannot play ${item.kind.name}.');
  }

  final id = item.kind == MediaKind.anime
      ? item.anilistId ?? _idFromString(item.id)
      : item.tmdbId ?? _idFromString(item.id);
  if (id == null || id <= 0) {
    throw MissingMediaIdException(
      '${item.title} has no ${item.kind == MediaKind.anime ? 'AniList' : 'TMDB'} id.',
    );
  }

  final type = item.kind == MediaKind.tv ? 'tv' : 'movie';
  var raw = provider.urlTemplate
      .replaceAll('{id}', id.toString())
      .replaceAll('{type}', type)
      .replaceAll('{season}', season.toString())
      .replaceAll('{episode}', episode.toString())
      .replaceAll(
        '{tvSuffix}',
        item.kind == MediaKind.tv ? '/$season/$episode' : '',
      );

  if (item.kind != MediaKind.tv) {
    raw = _stripSeasonQuery(raw);
  }

  final uri = Uri.tryParse(raw);
  if (uri == null || !uri.hasScheme) {
    throw ArgumentError('${provider.name} has an invalid URL template.');
  }
  return uri;
}

/// Removes season/episode parameters from a movie URL while keeping the
/// provider's other query parameters (Rive carries `type` and `id` there).
String _stripSeasonQuery(String raw) {
  final uri = Uri.tryParse(raw);
  if (uri == null || !uri.hasQuery) {
    return raw;
  }
  const keys = <String>{'s', 'e', 'season', 'episode'};
  if (!uri.queryParameters.keys.any(keys.contains)) {
    return raw;
  }
  final params = Map<String, String>.from(uri.queryParameters)
    ..removeWhere((key, _) => keys.contains(key));
  if (params.isEmpty) {
    return uri.toString().split('?').first;
  }
  return uri.replace(queryParameters: params).toString();
}

int? _idFromString(String id) {
  final tail = id.contains(':') ? id.split(':').last : id;
  return int.tryParse(tail);
}
