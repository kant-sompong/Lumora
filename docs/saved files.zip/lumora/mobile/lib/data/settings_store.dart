import 'package:material_ui/material_ui.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../theme/lumora_theme.dart';
import 'providers_registry.dart';

/// User settings persisted with shared_preferences.
///
/// Defaults follow the PC app: every provider enabled in PC order, CineSrc as
/// the default, dark theme, PC accent and full-size poster cards.
class AppSettings extends ChangeNotifier {
  AppSettings({
    String tmdbApiKey = '',
    List<String>? enabledProviderIds,
    String? defaultProviderId,
    ThemeMode themeMode = ThemeMode.dark,
    Color accent = LumoraTheme.accent,
    bool compactCards = false,
  }) : _tmdbApiKey = tmdbApiKey,
       _enabledProviderIds = _sanitizeIds(
         enabledProviderIds ?? defaultProviderIds,
       ),
       _themeMode = themeMode,
       _accent = accent,
       _compactCards = compactCards {
    final enabled = _enabledProviderIds;
    if (defaultProviderId != null && enabled.contains(defaultProviderId)) {
      _defaultProviderId = defaultProviderId;
    } else {
      _defaultProviderId = enabled.isEmpty ? null : enabled.first;
    }
  }

  static const String _keyTmdb = 'lumora.tmdbApiKey';
  static const String _keyEnabledProviders = 'lumora.enabledProviderIds';
  static const String _keyDefaultProvider = 'lumora.defaultProviderId';
  static const String _keyThemeMode = 'lumora.themeMode';
  static const String _keyAccent = 'lumora.accent';
  static const String _keyCompactCards = 'lumora.compactCards';

  /// All providers enabled, in PC order.
  static List<String> get defaultProviderIds =>
      allProviders.map((provider) => provider.id).toList(growable: false);

  String _tmdbApiKey;
  List<String> _enabledProviderIds;
  String? _defaultProviderId;
  ThemeMode _themeMode;
  Color _accent;
  bool _compactCards;

  String get tmdbApiKey => _tmdbApiKey;

  set tmdbApiKey(String value) {
    final trimmed = value.trim();
    if (_tmdbApiKey == trimmed) {
      return;
    }
    _tmdbApiKey = trimmed;
    notifyListeners();
  }

  /// Enabled providers in display/playback preference order.
  List<String> get enabledProviderIds => List.unmodifiable(_enabledProviderIds);

  set enabledProviderIds(List<String> value) {
    final next = _sanitizeIds(value);
    if (_sameIds(next, _enabledProviderIds)) {
      return;
    }
    _enabledProviderIds = next;
    if (_defaultProviderId == null ||
        !_enabledProviderIds.contains(_defaultProviderId)) {
      _defaultProviderId = _enabledProviderIds.isEmpty
          ? null
          : _enabledProviderIds.first;
    }
    notifyListeners();
  }

  String? get defaultProviderId => _defaultProviderId;

  set defaultProviderId(String? value) {
    if (value != null && !_enabledProviderIds.contains(value)) {
      return;
    }
    if (_defaultProviderId == value) {
      return;
    }
    _defaultProviderId = value;
    notifyListeners();
  }

  ThemeMode get themeMode => _themeMode;

  set themeMode(ThemeMode value) {
    if (_themeMode == value) {
      return;
    }
    _themeMode = value;
    notifyListeners();
  }

  Color get accent => _accent;

  set accent(Color value) {
    if (_accent.toARGB32() == value.toARGB32()) {
      return;
    }
    _accent = value;
    notifyListeners();
  }

  bool get compactCards => _compactCards;

  set compactCards(bool value) {
    if (_compactCards == value) {
      return;
    }
    _compactCards = value;
    notifyListeners();
  }

  /// Turns a provider on or off, keeping the existing order.
  void toggleProvider(String id, bool enabled) {
    if (providerById(id) == null) {
      return;
    }
    final next = List<String>.from(_enabledProviderIds);
    if (enabled) {
      if (!next.contains(id)) {
        next.add(id);
      }
    } else {
      next.remove(id);
    }
    enabledProviderIds = next;
  }

  /// Reads settings, replacing junk/missing values with defaults.
  static Future<AppSettings> load() async {
    final prefs = await SharedPreferences.getInstance();

    // Read through get() and type-check, so a junk value of the wrong type
    // falls back to the default instead of throwing a cast error.
    final rawIdsValue = prefs.get(_keyEnabledProviders);
    final rawIds = rawIdsValue is List
        ? rawIdsValue.whereType<String>().toList(growable: false)
        : null;
    var enabled = rawIds == null ? defaultProviderIds : _sanitizeIds(rawIds);
    if (enabled.isEmpty) {
      enabled = defaultProviderIds;
    }

    final rawDefaultValue = prefs.get(_keyDefaultProvider);
    final rawDefault = rawDefaultValue is String ? rawDefaultValue : null;
    final defaultId = rawDefault != null && enabled.contains(rawDefault)
        ? rawDefault
        : (enabled.isEmpty ? null : enabled.first);

    final rawThemeValue = prefs.get(_keyThemeMode);
    final rawTheme = rawThemeValue is String ? rawThemeValue : null;

    final accentValue = prefs.get(_keyAccent);
    final accent = accentValue is int ? Color(accentValue) : LumoraTheme.accent;

    final rawKey = prefs.get(_keyTmdb);
    final compactValue = prefs.get(_keyCompactCards);

    return AppSettings(
      tmdbApiKey: rawKey is String ? rawKey : '',
      enabledProviderIds: enabled,
      defaultProviderId: defaultId,
      themeMode: parseThemeMode(rawTheme),
      accent: accent,
      compactCards: compactValue is bool ? compactValue : false,
    );
  }

  /// Persists every setting. Call after changing fields if the UI wants it.
  Future<void> save() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_keyTmdb, _tmdbApiKey);
    await prefs.setStringList(_keyEnabledProviders, _enabledProviderIds);
    await prefs.setString(_keyDefaultProvider, _defaultProviderId ?? '');
    await prefs.setString(_keyThemeMode, themeModeName(_themeMode));
    await prefs.setInt(_keyAccent, _accent.toARGB32());
    await prefs.setBool(_keyCompactCards, _compactCards);
  }

  static ThemeMode parseThemeMode(String? raw) {
    switch (raw) {
      case 'light':
        return ThemeMode.light;
      case 'system':
        return ThemeMode.system;
      case 'dark':
      default:
        return ThemeMode.dark;
    }
  }

  static String themeModeName(ThemeMode mode) {
    switch (mode) {
      case ThemeMode.light:
        return 'light';
      case ThemeMode.system:
        return 'system';
      case ThemeMode.dark:
        return 'dark';
    }
  }

  static List<String> _sanitizeIds(List<String> ids) {
    final known = <String>{for (final provider in allProviders) provider.id};
    final seen = <String>{};
    final out = <String>[];
    for (final id in ids) {
      if (known.contains(id) && seen.add(id)) {
        out.add(id);
      }
    }
    return out;
  }

  static bool _sameIds(List<String> a, List<String> b) {
    if (a.length != b.length) {
      return false;
    }
    for (var i = 0; i < a.length; i++) {
      if (a[i] != b[i]) {
        return false;
      }
    }
    return true;
  }
}
