import 'media_item.dart';

/// A site that plays media in the full-screen web view.
class StreamProvider {
  const StreamProvider({
    required this.id,
    required this.name,
    required this.urlTemplate,
    required this.kinds,
  });

  /// Stable id persisted in [AppSettings.enabledProviderIds].
  final String id;
  final String name;

  /// URL template. Placeholders: `{id}` (TMDB or AniList id),
  /// `{type}` (`movie`/`tv`), `{season}` and `{episode}`.
  ///
  /// Movie URLs drop the query string, so a TV template such as
  /// `.../tv/{id}?s={season}&e={episode}` also describes its movie form.
  final String urlTemplate;

  /// The kinds this provider can play.
  final Set<MediaKind> kinds;

  bool supports(MediaKind kind) => kinds.contains(kind);
}

/// Thrown when an item has no TMDB/AniList id to build a watch URL from.
class MissingMediaIdException implements Exception {
  const MissingMediaIdException(this.message);

  final String message;

  @override
  String toString() => 'MissingMediaIdException: $message';
}
