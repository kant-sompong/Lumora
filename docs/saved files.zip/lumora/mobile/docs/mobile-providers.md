# Mobile media providers

The Flutter app plays media in **one full-screen WebView**. No browser chrome is
shown; popups/new windows and navigation away from the provider are blocked by
the player (agent C).

## Source

The provider list is copied from the PC app's `lgl/streaming.py` (commit
`4ddb540`, the commit this repo pins): `PROVIDERS`, `ANIME_PROVIDERS`,
`LABELS`, `movie_url()`, `episode_url()` and `ani_url()`. The settings labels
come from the same file and from `preview/settings-media.png`.

The anime metadata source differs by contract: the PC uses MyAnimeList, while
the mobile app uses AniList (no extra key). Playback is still ani.pm, keyed by
AniList id instead of MAL id, per the mobile contract.

## Providers (`lib/data/providers_registry.dart`)

PC order, same ids and labels.

| id | name | kinds | movie URL template | TV URL template | source |
| --- | --- | --- | --- | --- | --- |
| `cinesrc` | CineSrc | movie, tv | `https://cinesrc.st/embed/movie/{id}` | `https://cinesrc.st/embed/tv/{id}?s={season}&e={episode}` | `streaming.movie_url` / `episode_url` |
| `rivestream` | Rive | movie, tv | `https://www.rivestream.app/embed?type=movie&id={id}` | `https://www.rivestream.app/embed?type=tv&id={id}&season={season}&episode={episode}` | same |
| `toflix` | ToFlix | movie, tv | `https://toflix.co/embed/movie/{id}` | `https://toflix.co/embed/tv/{id}/{season}/{episode}` | same |
| `cinelite` | CineLite | movie, tv | `https://embed.cinelite.xyz/{id}` | `https://embed.cinelite.xyz/{id}/{season}/{episode}` | same |
| `framextv` | frameXTV | movie, tv | `https://framextv.xyz/embed/{id}` | `https://framextv.xyz/embed/{id}/{season}/{episode}` | same |
| `atlantic` | Atlantic | movie, tv | `https://atlantic.st/embed/movie/{id}` | `https://atlantic.st/embed/tv/{id}/{season}/{episode}` | same |
| `ani` | ani.pm (anime) | anime | — | — | `streaming.ani_url` |

Anime (all providers that support it): `https://ani.pm/embed/ani/{anilistId}/{episode}/{sub|dub|vostfr}`
in the PC; the mobile contract has no audio setting, so the registry pins the
PC default `sub`: `https://ani.pm/embed/ani/{anilistId}/{episode}/sub`.

The PC also documents optional AniList routes for ToFlix
(`https://toflix.co/embed/anime/{anilistId}/{episode}`) and CineLite
(`https://embed.cinelite.xyz/anime/{anilistId}/{episode}`). They are fallbacks
in the PC (`ANILIST_ANIME_PROVIDERS`) and are **not** exposed on mobile: the
mobile contract has a single default provider and ani.pm is the anime provider
shown in PC settings. They can be added later without changing the contract.

## Templates

`StreamProvider.urlTemplate` keeps one string per provider:

- `{id}` – TMDB id for movies/TV, AniList id for anime.
- `{type}` – `movie` or `tv`.
- `{season}`, `{episode}` – numbers.
- `{tvSuffix}` – `/{season}/{episode}` for TV, empty for movies.

For movies, `buildWatchUrl` also removes season/episode query parameters, so
CineSrc becomes `/embed/movie/{id}` and Rive keeps only `type` and `id`.

## API

```dart
const List<StreamProvider> allProviders;
StreamProvider? providerById(String id);
List<StreamProvider> providersForKind(MediaKind kind);
StreamProvider? pickProvider({
  required MediaKind kind,
  List<String>? enabledProviderIds,
  String? preferredId,
});
Uri buildWatchUrl(
  StreamProvider provider,
  MediaItem item, {
  int season = 1,
  int episode = 1,
});
```

- Wrong kind → `ArgumentError`; missing id → `MissingMediaIdException`.
- `pickProvider` skips providers that cannot play the kind, so anime does not
  try CineSrc even when CineSrc is the stored default.

## Other PC references

- Palette, spacing, radii and type: `lgl/theme.py` (`DARK`, `LIGHT`,
  `ACCENT`, `ACCENT_FILL`, `SPACE`, `RADIUS`, `TYPE`).
- Home shelves/order: `lgl/qt_media.py` `_load_home()` / `_load_anime()`:
  Trending Now (trending movies + trending TV, max 20), Movies (popular),
  TV Shows (popular), Anime (popular).
- Settings rows: `lgl/qt_settings.py` Providers/Media tabs and
  `lgl/streaming.py`.
