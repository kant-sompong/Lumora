import 'package:material_ui/material_ui.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:lumora_mobile/theme/lumora_theme.dart';

void main() {
  group('onAccent', () {
    test('uses white on a dark accent', () {
      expect(LumoraTheme.onAccent(const Color(0xFF101216)), Colors.white);
    });

    test('does not put white on the 3.7:1 chart accent', () {
      expect(LumoraTheme.onAccent(LumoraTheme.accent), const Color(0xFF0B0E14));
    });

    test('uses ink on a light accent', () {
      expect(
        LumoraTheme.onAccent(const Color(0xFFFFE066)),
        const Color(0xFF0B0E14),
      );
    });
  });

  test('accentWash tints the surface', () {
    final wash = LumoraTheme.accentWash(
      LumoraTheme.accent,
      LumoraTheme.darkSurface,
    );
    expect(wash, isNot(LumoraTheme.darkSurface));
    expect(wash.a, 1);
  });

  test('filled() keeps the PC fill and darkens unsafe accents', () {
    expect(LumoraTheme.filled(LumoraTheme.accent), LumoraTheme.accentFill);
    final light = LumoraTheme.filled(const Color(0xFFFFE066));
    expect(
      LumoraTheme.contrastRatio(light, Colors.white),
      greaterThanOrEqualTo(4.5),
    );
    expect(LumoraTheme.onAccent(light), Colors.white);
  });

  test('dark theme uses the sampled PC palette and accent', () {
    const accent = Color(0xFF00AA88);
    final theme = LumoraTheme.dark(accent);

    expect(theme.brightness, Brightness.dark);
    expect(theme.scaffoldBackgroundColor, LumoraTheme.darkBackground);
    expect(theme.colorScheme.primary, accent);
    expect(theme.colorScheme.surface, LumoraTheme.darkSurface);
    expect(theme.appBarTheme.backgroundColor, LumoraTheme.darkBackground);
    expect(theme.extension<LumoraColors>()?.muted, LumoraTheme.darkMuted);
    expect(theme.extension<LumoraColors>()?.raised, LumoraTheme.darkRaised);
    expect(theme.extension<LumoraColors>()?.divider, LumoraTheme.darkDivider);
  });

  test('light theme uses the light palette and contrast-safe labels', () {
    const accent = Color(0xFFFFE066);
    final theme = LumoraTheme.light(accent);

    expect(theme.brightness, Brightness.light);
    expect(theme.scaffoldBackgroundColor, LumoraTheme.lightBackground);
    expect(theme.colorScheme.primary, accent);
    expect(theme.colorScheme.onPrimary, Colors.white);
    expect(theme.colorScheme.surface, LumoraTheme.lightSurface);
  });
}
