import 'package:flutter_test/flutter_test.dart';
import 'package:lumora_mobile/data/providers_registry.dart';
import 'package:lumora_mobile/models/media_item.dart';
import 'package:lumora_mobile/models/stream_provider.dart';

void main() {
  final cinesrc = providerById('cinesrc')!;
  final anipm = providerById('ani')!;

  const movie = MediaItem(
    id: 'tmdb:693134',
    title: 'Dune: Part Two',
    kind: MediaKind.movie,
    tmdbId: 693134,
  );
  const show = MediaItem(
    id: 'tmdb:1396',
    title: 'Breaking Bad',
    kind: MediaKind.tv,
    tmdbId: 1396,
  );
  const anime = MediaItem(
    id: 'anilist:154587',
    title: 'Frieren',
    kind: MediaKind.anime,
    anilistId: 154587,
  );

  group('registry', () {
    test('keeps the PC provider list, order and labels', () {
      expect(allProviders.map((provider) => provider.id), <String>[
        'cinesrc',
        'rivestream',
        'toflix',
        'cinelite',
        'framextv',
        'atlantic',
        'ani',
      ]);
      expect(allProviders.map((provider) => provider.name), <String>[
        'CineSrc',
        'Rive',
        'ToFlix',
        'CineLite',
        'frameXTV',
        'Atlantic',
        'ani.pm (anime)',
      ]);
    });

    test('finds providers by id and kind', () {
      expect(providerById('nope'), isNull);
      expect(
        providersForKind(MediaKind.movie).map((provider) => provider.id),
        <String>[
          'cinesrc',
          'rivestream',
          'toflix',
          'cinelite',
          'framextv',
          'atlantic',
        ],
      );
      expect(
        providersForKind(MediaKind.anime).map((provider) => provider.id),
        <String>['ani'],
      );
    });
  });

  group('buildWatchUrl', () {
    test('movie uses the TMDB id without a query string', () {
      final url = buildWatchUrl(cinesrc, movie);
      expect(url.toString(), 'https://cinesrc.st/embed/movie/693134');
    });

    test('TV adds season and episode', () {
      final url = buildWatchUrl(cinesrc, show, season: 2, episode: 5);
      expect(url.toString(), 'https://cinesrc.st/embed/tv/1396?s=2&e=5');
    });

    test('every PC provider builds its movie and TV URL', () {
      const expectedMovie = <String, String>{
        'cinesrc': 'https://cinesrc.st/embed/movie/603',
        'rivestream': 'https://www.rivestream.app/embed?type=movie&id=603',
        'toflix': 'https://toflix.co/embed/movie/603',
        'cinelite': 'https://embed.cinelite.xyz/603',
        'framextv': 'https://framextv.xyz/embed/603',
        'atlantic': 'https://atlantic.st/embed/movie/603',
      };
      const expectedTv = <String, String>{
        'cinesrc': 'https://cinesrc.st/embed/tv/1396?s=2&e=5',
        'rivestream':
            'https://www.rivestream.app/embed?type=tv&id=1396&season=2&episode=5',
        'toflix': 'https://toflix.co/embed/tv/1396/2/5',
        'cinelite': 'https://embed.cinelite.xyz/1396/2/5',
        'framextv': 'https://framextv.xyz/embed/1396/2/5',
        'atlantic': 'https://atlantic.st/embed/tv/1396/2/5',
      };
      const matrix = MediaItem(
        id: 'tmdb:603',
        title: 'The Matrix',
        kind: MediaKind.movie,
        tmdbId: 603,
      );
      for (final entry in expectedMovie.entries) {
        expect(
          buildWatchUrl(providerById(entry.key)!, matrix).toString(),
          entry.value,
          reason: entry.key,
        );
        expect(
          buildWatchUrl(
            providerById(entry.key)!,
            show,
            season: 2,
            episode: 5,
          ).toString(),
          expectedTv[entry.key],
          reason: entry.key,
        );
      }
    });

    test('anime uses the AniList id and episode', () {
      final url = buildWatchUrl(anipm, anime, episode: 7);
      expect(url.toString(), 'https://ani.pm/embed/ani/154587/7/sub');
    });

    test('falls back to the numeric part of the id', () {
      const noField = MediaItem(
        id: 'tmdb:603',
        title: 'The Matrix',
        kind: MediaKind.movie,
      );
      expect(
        buildWatchUrl(cinesrc, noField).toString(),
        'https://cinesrc.st/embed/movie/603',
      );
    });

    test('throws for a provider that cannot play the kind', () {
      expect(
        () => buildWatchUrl(cinesrc, anime),
        throwsA(isA<ArgumentError>()),
      );
      expect(() => buildWatchUrl(anipm, movie), throwsA(isA<ArgumentError>()));
    });

    test('throws when the item has no usable id', () {
      const broken = MediaItem(
        id: 'local',
        title: 'Unknown',
        kind: MediaKind.movie,
      );
      expect(
        () => buildWatchUrl(cinesrc, broken),
        throwsA(isA<MissingMediaIdException>()),
      );
    });
  });

  group('pickProvider', () {
    test('skips providers that do not support the kind', () {
      final picked = pickProvider(
        kind: MediaKind.anime,
        preferredId: 'cinesrc',
      );
      expect(picked?.id, 'ani');
    });

    test('honours an enabled matching preference', () {
      final picked = pickProvider(
        kind: MediaKind.movie,
        enabledProviderIds: <String>['ani', 'cinesrc'],
        preferredId: 'cinesrc',
      );
      expect(picked?.id, 'cinesrc');
    });

    test('returns null when nothing enabled can play the kind', () {
      expect(
        pickProvider(
          kind: MediaKind.movie,
          enabledProviderIds: <String>['ani'],
        ),
        isNull,
      );
    });
  });
}
