import 'dart:convert';
import 'dart:io';

import 'package:flutter_test/flutter_test.dart';
import 'package:lumora_mobile/data/media_repository.dart';
import 'package:lumora_mobile/models/media_item.dart';

Map<String, dynamic> fixture(String name) {
  final file = File('test/data/fixtures/$name');
  return jsonDecode(file.readAsStringSync()) as Map<String, dynamic>;
}

void main() {
  group('TMDB parsing', () {
    test('parses a trending list defensively', () {
      final json = fixture('tmdb_trending_movie.json');
      final items = parseTmdbResults(json, kindOverride: MediaKind.movie);

      expect(items, hasLength(2));
      final dune = items.first;
      expect(dune.id, 'tmdb:693134');
      expect(dune.tmdbId, 693134);
      expect(dune.title, 'Dune: Part Two');
      expect(dune.kind, MediaKind.movie);
      expect(dune.year, '2024');
      expect(dune.rating, 8.2);
      expect(
        dune.posterUrl,
        'https://image.tmdb.org/t/p/w500/1pdfLvkbY9ohJlCjQH2CZjjYVvJ.jpg',
      );

      final batman = items.last;
      expect(batman.posterUrl, isNull);
      expect(batman.backdropUrl, isNull);
      expect(batman.year, isNull);
      expect(batman.rating, isNull);
      expect(batman.overview, isNull);
    });

    test('parses TV lists using name and first_air_date', () {
      final items = parseTmdbResults(fixture('tmdb_popular_tv.json'));

      expect(items, hasLength(2));
      expect(items.first.kind, MediaKind.tv);
      expect(items.first.title, 'Severance');
      expect(items.first.year, '2022');
      expect(items.last.title, 'Shōgun');
      expect(items.last.posterUrl, isNull);
    });

    test('parses movie detail with runtime, tagline and genres', () {
      final detail = parseTmdbDetail(
        fixture('tmdb_movie_detail.json'),
        kind: MediaKind.movie,
      );

      expect(detail, isNotNull);
      expect(detail!.item.title, 'Dune: Part Two');
      expect(detail.runtimeMinutes, 167);
      expect(detail.tagline, 'Long live the fighters.');
      expect(detail.seasons, isEmpty);
      expect(detail.item.genres, <String>['Science Fiction', 'Adventure']);
    });

    test('parses TV detail seasons in order and falls back to run time', () {
      final detail = parseTmdbDetail(
        fixture('tmdb_tv_detail.json'),
        kind: MediaKind.tv,
      );

      expect(detail, isNotNull);
      expect(detail!.runtimeMinutes, 50);
      expect(detail.tagline, 'Who are you?');
      expect(detail.item.genres, hasLength(3));
      expect(detail.seasons.map((season) => season.number), <int>[0, 1, 2]);
      expect(detail.seasons.map((season) => season.episodeCount), <int>[
        2,
        9,
        10,
      ]);
      expect(detail.seasons[1].name, 'Season 1');
    });

    test('returns empty/null instead of throwing on junk', () {
      expect(parseTmdbResults(<String, dynamic>{}), isEmpty);
      expect(parseTmdbResults(<String, dynamic>{'results': 'nope'}), isEmpty);
      expect(
        parseTmdbDetail(<String, dynamic>{}, kind: MediaKind.movie),
        isNull,
      );
      expect(parseTmdbItem(<String, dynamic>{'id': 5}), isNull);
    });
  });

  group('AniList parsing', () {
    test('parses a Page with titles, covers and scores', () {
      final items = parseAniListPage(fixture('anilist_trending.json'));

      expect(items, hasLength(2));
      final frieren = items.first;
      expect(frieren.id, 'anilist:154587');
      expect(frieren.anilistId, 154587);
      expect(frieren.kind, MediaKind.anime);
      expect(frieren.title, "Frieren: Beyond Journey's End");
      expect(frieren.year, '2023');
      expect(frieren.rating, 9.3);
      expect(frieren.genres, <String>['Adventure', 'Drama', 'Fantasy']);
      expect(frieren.overview, 'After the party, an elf retraces the journey.');
      expect(frieren.posterUrl, contains('bx154587'));

      final onePiece = items.last;
      expect(onePiece.title, 'One Piece');
      expect(onePiece.posterUrl, isNull);
      expect(onePiece.year, isNull);
      expect(onePiece.rating, 8.8);
      expect(onePiece.genres, isEmpty);
      expect(onePiece.backdropUrl, contains('banner'));
    });

    test('parses anime detail with one season of episodes', () {
      final raw = fixture('anilist_media_detail.json');
      final detail = parseAniListDetail(raw['Media'] as Map<String, dynamic>);

      expect(detail, isNotNull);
      expect(detail!.item.title, 'Attack on Titan');
      expect(detail.runtimeMinutes, 24);
      expect(detail.seasons, hasLength(1));
      expect(detail.seasons.first.number, 1);
      expect(detail.seasons.first.episodeCount, 25);
      expect(detail.item.overview, contains('Humanity fights & survives.'));
      expect(detail.item.overview, isNot(contains('<')));
    });

    test('returns empty/null instead of throwing on junk', () {
      expect(parseAniListPage(<String, dynamic>{}), isEmpty);
      expect(
        parseAniListPage(<String, dynamic>{'Page': <String, dynamic>{}}),
        isEmpty,
      );
      expect(parseAniListMedia(<String, dynamic>{}), isNull);
    });
  });

  group('FakeMediaRepository', () {
    const repository = FakeMediaRepository();

    test('home has 3+ shelves with 12+ unique titles of every kind', () async {
      final shelves = await repository.home();

      expect(shelves.length, greaterThanOrEqualTo(3));
      final all = <String, MediaItem>{
        for (final shelf in shelves)
          for (final item in shelf.items) item.id: item,
      };
      expect(all.length, greaterThanOrEqualTo(12));
      expect(
        all.values.map((item) => item.kind).toSet(),
        containsAll(<MediaKind>[
          MediaKind.movie,
          MediaKind.tv,
          MediaKind.anime,
        ]),
      );
      expect(all.values.where((item) => item.posterUrl == null), isNotEmpty);
    });

    test('search is case-insensitive and blank returns nothing', () async {
      expect(await repository.search('   '), isEmpty);
      final results = await repository.search('dune');
      expect(results.map((item) => item.title), contains('Dune: Part Two'));
      expect((await repository.search('zzzz')), isEmpty);
    });

    test('detail returns movie runtime and TV/anime seasons', () async {
      final movie = await repository.detail(
        FakeMediaRepository.items.firstWhere(
          (item) => item.kind == MediaKind.movie,
        ),
      );
      expect(movie.seasons, isEmpty);
      expect(movie.runtimeMinutes, isNotNull);

      final show = await repository.detail(
        FakeMediaRepository.items.firstWhere((item) => item.id == 'tmdb:95396'),
      );
      expect(show.seasons, hasLength(2));
      expect(
        show.seasons.fold<int>(0, (sum, season) => sum + season.episodeCount),
        9,
      );

      final anime = await repository.detail(
        FakeMediaRepository.items.firstWhere(
          (item) => item.kind == MediaKind.anime,
        ),
      );
      expect(anime.seasons, hasLength(1));
      expect(anime.runtimeMinutes, 24);
    });
  });
}
