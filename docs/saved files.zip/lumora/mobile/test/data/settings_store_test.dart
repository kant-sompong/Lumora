import 'package:material_ui/material_ui.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:lumora_mobile/data/providers_registry.dart';
import 'package:lumora_mobile/data/settings_store.dart';
import 'package:lumora_mobile/theme/lumora_theme.dart';
import 'package:shared_preferences/shared_preferences.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();

  setUp(() {
    SharedPreferences.setMockInitialValues(<String, Object>{});
  });

  test('defaults follow the PC app', () async {
    final settings = await AppSettings.load();
    expect(settings.tmdbApiKey, '');
    expect(
      settings.enabledProviderIds,
      allProviders.map((provider) => provider.id).toList(),
    );
    expect(settings.defaultProviderId, 'cinesrc');
    expect(settings.themeMode, ThemeMode.dark);
    expect(settings.accent, LumoraTheme.accent);
    expect(settings.compactCards, isFalse);
  });

  test('save/load round trip keeps every field', () async {
    final settings = await AppSettings.load();
    settings.tmdbApiKey = '  test-key  ';
    settings.enabledProviderIds = <String>['ani', 'cinesrc'];
    settings.defaultProviderId = 'ani';
    settings.themeMode = ThemeMode.light;
    settings.accent = const Color(0xFFAA3300);
    settings.compactCards = true;
    await settings.save();

    final reloaded = await AppSettings.load();
    expect(reloaded.tmdbApiKey, 'test-key');
    expect(reloaded.enabledProviderIds, <String>['ani', 'cinesrc']);
    expect(reloaded.defaultProviderId, 'ani');
    expect(reloaded.themeMode, ThemeMode.light);
    expect(reloaded.accent, const Color(0xFFAA3300));
    expect(reloaded.compactCards, isTrue);
  });

  test('junk string values fall back to defaults', () async {
    SharedPreferences.setMockInitialValues(<String, Object>{
      'lumora.tmdbApiKey': 42,
      'lumora.enabledProviderIds': ['ghost', 'ani', 'ani', 7],
      'lumora.defaultProviderId': 'ghost',
      'lumora.themeMode': 'neon',
      'lumora.accent': 'blue',
      'lumora.compactCards': 'yes',
    });

    final settings = await AppSettings.load();
    expect(settings.tmdbApiKey, '');
    expect(settings.enabledProviderIds, <String>['ani']);
    expect(settings.defaultProviderId, 'ani');
    expect(settings.themeMode, ThemeMode.dark);
    expect(settings.accent, LumoraTheme.accent);
    expect(settings.compactCards, isFalse);
  });

  test('all-unknown provider ids fall back to every provider', () async {
    SharedPreferences.setMockInitialValues(<String, Object>{
      'lumora.enabledProviderIds': <String>['ghost', 'phantom'],
      'lumora.defaultProviderId': 'phantom',
    });

    final settings = await AppSettings.load();
    expect(settings.enabledProviderIds, AppSettings.defaultProviderIds);
    expect(settings.defaultProviderId, allProviders.first.id);
  });

  test('toggling providers preserves order and fixes the default', () {
    final settings = AppSettings();
    settings.toggleProvider('cinesrc', false);
    expect(settings.enabledProviderIds.first, 'rivestream');
    expect(settings.defaultProviderId, 'rivestream');

    settings.toggleProvider('cinesrc', true);
    expect(settings.enabledProviderIds.last, 'cinesrc');
    expect(settings.defaultProviderId, 'rivestream');

    settings.enabledProviderIds = <String>['ani'];
    expect(settings.enabledProviderIds, <String>['ani']);
    settings.defaultProviderId = 'cinesrc';
    expect(settings.defaultProviderId, 'ani');
  });

  test('theme mode names round trip', () {
    for (final mode in ThemeMode.values) {
      expect(AppSettings.parseThemeMode(AppSettings.themeModeName(mode)), mode);
    }
    expect(AppSettings.parseThemeMode(null), ThemeMode.dark);
  });
}
