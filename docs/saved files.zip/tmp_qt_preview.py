"""Render the Qt UI offscreen to PNG files for visual review (dev helper)."""

from __future__ import annotations

import os
import sys
import time
from pathlib import Path

os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")
ROOT = Path(__file__).resolve().parent / "Lumora"
sys.path.insert(0, str(ROOT))

from PySide6.QtWidgets import QApplication  # noqa: E402

from lgl import qt_main  # noqa: E402
from lgl.archive import GameSummary  # noqa: E402
from lgl.downloader import DownloadManager  # noqa: E402
from lgl.library_store import LibraryEntry  # noqa: E402
from lgl.qt_settings import AboutDialog, SettingsDialog  # noqa: E402
from lgl.settings import Settings  # noqa: E402

OUT = Path(__file__).resolve().parent / "preview"
OUT.mkdir(exist_ok=True)

GAMES = [
    ("cod-mw", "Call of Duty: Modern Warfare", "2023", 170 * 1024**3, "link unchecked", ["Action", "Shooter"], "Activision"),
    ("stalker2", "S.T.A.L.K.E.R. 2: Heart of Chornobyl", "2024", 159 * 1024**3, "link unchecked", ["Action RPG", "Survival"], "GSC Game World"),
    ("cod-cw", "Call of Duty: Black Ops Cold War", "2023", 157 * 1024**3, "link unchecked", ["Shooter"], "Treyarch"),
    ("wukong", "Black Myth: Wukong", "2024", 150 * 1024**3, "link unchecked", ["Action RPG"], "Game Science"),
    ("cyberpunk", "Cyberpunk 2077", "2020", 144 * 1024**3, "link unchecked", ["Action RPG", "Open World"], "CD Projekt Red"),
    ("bg3", "Baldur's Gate 3", "2023", 132 * 1024**3, "link unchecked", ["Adventure", "RPG"], "Larian Studios"),
    ("ds2", "DEATH STRANDING 2: ON THE BEACH", "2026", 132 * 1024**3, "link unchecked", ["Adventure"], "Kojima Productions"),
    ("forza", "Forza Horizon 6", "2026", 125 * 1024**3, "no download link", ["Racing"], "Playground Games"),
    ("spidey", "Marvel's Spider-Man 2", "2025", 122 * 1024**3, "link unchecked", ["Action"], "Insomniac Games"),
    ("indy", "Indiana Jones and the Great Circle", "2024", 120 * 1024**3, "link unchecked", ["Adventure"], "MachineGames"),
    ("oblivion", "The Elder Scrolls IV: Oblivion Remastered", "2025", 116 * 1024**3, "link unchecked", ["RPG"], "Bethesda"),
    ("re4", "Resident Evil 4", "2023", 98 * 1024**3, "link unchecked", ["Survival"], "Capcom"),
]


def sample_games():
    out = []
    for identifier, title, year, size, state, subjects, creator in GAMES:
        out.append(GameSummary(
            identifier=identifier, title=title, year=year, downloads=12000,
            item_size=size, creator=creator, subjects=list(subjects),
            licenseurl="https://creativecommons.org/licenses/by/4.0/",
            catalog_key=f"kryoto:{identifier}", catalog_source="Kryoto",
            download_state=state,
        ))
    return out


def sample_library():
    entries = []
    for index, (identifier, title, year, size, state, subjects, creator) in enumerate(GAMES[:6]):
        entries.append(LibraryEntry(
            identifier=identifier, title=title, year=year, creator=creator,
            folder="/tmp/games", size=size // 4, file_count=912 + index,
            favorite=index == 0, status="downloaded", compatibility="Windows",
            integrity="" if index else "Verified (912 files)",
            added_at=time.time() - index * 8000, last_seen=time.time() - index * 500,
            developer=creator, genres=tuple(subjects), description=(
                "A sample description used to check the detail panel layout while the "
                "real metadata is not loaded."
            ),
        ))
    return entries


def main() -> int:
    app = QApplication.instance() or QApplication([])
    settings = Settings(Path("/tmp/lgl-preview/config.json"))
    qt_main.apply_theme(app, "dark")
    manager = DownloadManager(queue_path=Path("/tmp/lgl-preview/queue.json"),
                              observer=lambda: None, validate_urls=False)
    window = qt_main.Window(None, None, manager, Path("/tmp/games"), settings)
    window.resize(1600, 1000)
    window.show()
    window.library.set_entries(sample_library())
    window.browse.set_games(sample_games())
    app.processEvents()

    shots = [
        ("browse", "browse.png"),
        ("library", "library.png"),
        ("downloads", "downloads.png"),
        ("media", "media.png"),
    ]
    for key, name in shots:
        window.show_view(key)
        window._current = key
        window._sync_rail()
        app.processEvents()
        time.sleep(0.15)
        app.processEvents()
        window.grab().save(str(OUT / name))
        print("wrote", name)

    # Browse list view
    window.show_view("browse")
    window.browse._toggle_view()
    app.processEvents()
    window.grab().save(str(OUT / "browse-list.png"))

    # Library with detail panel
    window.show_view("library")
    window.library.select(window.library._shown[0].identifier)
    app.processEvents()
    window.grab().save(str(OUT / "library-detail.png"))

    # Browse selection
    window.show_view("browse")
    window.browse._toggle_view()
    window.browse.select("cyberpunk")
    app.processEvents()
    time.sleep(0.1)
    window.grab().save(str(OUT / "browse-detail.png"))

    dialog = SettingsDialog(settings, window)
    dialog.resize(700, 590)
    dialog.show()
    app.processEvents()
    dialog.grab().save(str(OUT / "settings-general.png"))
    dialog.show_tab("providers")
    app.processEvents()
    dialog.grab().save(str(OUT / "settings-providers.png"))
    dialog.show_tab("media")
    app.processEvents()
    dialog.grab().save(str(OUT / "settings-media.png"))
    dialog.close()

    about = AboutDialog(window)
    about.show()
    app.processEvents()
    about.grab().save(str(OUT / "about.png"))
    about.close()
    manager.shutdown()
    return 0


if __name__ == "__main__":
    sys.exit(main())
