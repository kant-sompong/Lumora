"""Render the Qt UI offscreen so its layout can be inspected as real pixels.

    python qt_shots.py <outdir> [scale]

Writes PNGs for the main window (all four pages), the game detail panel,
every Settings tab, and About, in dark and light.  Uses temporary XDG
directories, so it never reads or writes the real user profile.
"""

from __future__ import annotations

import os
import sys
import tempfile
from pathlib import Path

scale = sys.argv[2] if len(sys.argv) > 2 else "1"
os.environ["QT_QPA_PLATFORM"] = "offscreen"
os.environ["QT_SCALE_FACTOR"] = scale
os.environ["QT_LOGGING_RULES"] = "qt.qpa.*=false"

root = Path(__file__).resolve().parent
sys.path.insert(0, str(root / "Lumora"))

profile = Path(tempfile.mkdtemp(prefix="lumora-shots-"))
os.environ["XDG_CONFIG_HOME"] = str(profile / "config")
os.environ["XDG_DATA_HOME"] = str(profile / "data")
os.environ["XDG_CACHE_HOME"] = str(profile / "cache")

out = Path(sys.argv[1])
out.mkdir(parents=True, exist_ok=True)

from PySide6.QtCore import Qt  # noqa: E402
from PySide6.QtGui import (  # noqa: E402
    QColor, QFont, QFontDatabase, QLinearGradient, QPainter, QPixmap,
)
from PySide6.QtWidgets import QApplication  # noqa: E402

from lgl import platform_support, qt_main  # noqa: E402
from lgl.archive import ArchiveItem  # noqa: E402
from lgl.library_store import LibraryEntry, LibraryStore  # noqa: E402
from lgl.qt_settings import AboutDialog, SettingsDialog  # noqa: E402
from lgl.settings import Settings  # noqa: E402

app = QApplication.instance() or QApplication([])

# This VM has no fontconfig setup, so every string would render as a box.
for ttf in sorted((root / "fonts").glob("*.ttf")):
    QFontDatabase.addApplicationFont(str(ttf))
app.setFont(QFont("DejaVu Sans", 10))

platform_support.ensure_app_dirs()
settings = Settings(profile / "config.json")
settings.set("rescan_on_startup", False)

COVERS = [
    ("#3b5b8c", "#8fb3d9"), ("#7a3b52", "#d98fa8"), ("#2f6b52", "#7fd9b0"),
    ("#6b5b2f", "#d9c07f"), ("#4b3b7a", "#a88fd9"), ("#7a4b2f", "#d9a07f"),
]


def cover(index: int, path: Path) -> str:
    pix = QPixmap(360, 480)
    gradient = QLinearGradient(0, 0, 360, 480)
    gradient.setColorAt(0.0, QColor(COVERS[index][0]))
    gradient.setColorAt(1.0, QColor(COVERS[index][1]))
    painter = QPainter(pix)
    painter.fillRect(pix.rect(), gradient)
    painter.setPen(QColor("#ffffff"))
    font = painter.font()
    font.setPointSize(46)
    font.setBold(True)
    painter.setFont(font)
    painter.drawText(pix.rect(), Qt.AlignCenter, chr(ord("A") + index))
    painter.end()
    pix.save(str(path))
    return str(path)


downloads = profile / "downloads"
downloads.mkdir(parents=True, exist_ok=True)
store = LibraryStore(None, downloads)
titles = [
    ("demo_game", "Demo Game", "2020", 734003200, "installed"),
    ("space_runner", "Space Runner", "2019", 2147483648, "downloaded"),
    ("puzzle_box", "Puzzle Box Deluxe", "2021", 104857600, "downloaded"),
    ("night_drive", "Night Drive", "2018", 536870912, "incomplete"),
    ("castle_quest", "Castle Quest", "2022", 3221225472, "installed"),
    ("tiny_racer", "Tiny Racer", "2023", 52428800, "downloaded"),
]
for index, (identifier, title, year, size, status) in enumerate(titles):
    folder = downloads / identifier
    folder.mkdir(parents=True, exist_ok=True)
    (folder / "game.zip").write_bytes(b"PK\x03\x04" + b"0" * 128)
    store.upsert(LibraryEntry(
        identifier=identifier,
        title=title,
        year=year,
        size=size,
        status=status,
        creator="Demo Studio",
        genres=("Action", "Adventure") if index % 2 else ("Puzzle",),
        platforms=("Linux",),
        folder=str(folder),
        cover_path=cover(index, profile / f"cover{index}.png"),
        favorite=index in (1, 4),
    ))

manager = __import__('lgl.downloader', fromlist=['DownloadManager']).DownloadManager(
    observer=None, validate_urls=False, queue_path=profile / 'downloads.json'
)
window = qt_main.Window(store, None, manager, downloads, settings)
window.resize(int(__import__('os').environ.get('SHOT_W', 1240)), int(__import__('os').environ.get('SHOT_H', 820)))
window.library.set_entries(store.entries())
window.resize(1240, 820)


def pump() -> None:
    for _ in range(8):
        app.processEvents()


def save(widget, name: str) -> None:
    pump()
    path = out / f"{name}.png"
    widget.grab().save(str(path))
    print(f"{path}  {widget.width()}x{widget.height()}")


item = ArchiveItem(
    identifier="demo_game",
    title="Demo Game",
    description=(
        "A short description of the demo game that wraps across the panel so "
        "the typography and line height can be judged. It mentions that the "
        "game runs on Linux and was published in 2020.\n\nA second paragraph "
        "keeps the description area from looking empty."
    ),
    creator="Demo Studio",
    date="2020-05-01",
    year="2020",
    licenseurl="https://creativecommons.org/licenses/by/4.0/",
    rights="CC BY 4.0",
    item_size=734003200,
)

for mode in ("dark", "light"):
    qt_main.apply_theme(app, mode)
    app.setFont(QFont("DejaVu Sans", 10))
    window.show()
    pump()
    window.show_view("library")
    pump()
    save(window, f"{mode}_1_library_grid")

    window.library._toggle_view()
    pump()
    save(window, f"{mode}_2_library_list")
    window.library._toggle_view()
    pump()

    window.library.select("demo_game")
    pump()
    save(window, f"{mode}_3_library_detail")

    window.show_view("browse")
    pump()
    save(window, f"{mode}_4_browse")

    window.browse.detail.show_item(item)
    window.browse.detail.show()
    pump()
    save(window, f"{mode}_5_detail")
    window.browse.detail.hide()

    window.show_view("media")
    pump()
    save(window, f"{mode}_6_media")

    window.show_view("downloads")
    pump()
    save(window, f"{mode}_7_downloads")

    dialog = SettingsDialog(settings)
    dialog.resize(820, 700)
    dialog.show()
    for index, key in enumerate(list(dialog._tabs)):
        dialog.show_tab(key)
        pump()
        save(dialog, f"{mode}_8_settings_{index}_{key}")
    dialog.close()

    about = AboutDialog()
    about.show()
    pump()
    save(about, f"{mode}_9_about")
    about.close()
    window.close()

print("scale", scale, "DPR", app.devicePixelRatio(),
      "families", QFontDatabase.families()[:3])
